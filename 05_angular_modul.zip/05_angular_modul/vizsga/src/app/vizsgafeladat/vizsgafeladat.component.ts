import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vizsgafeladat',
  templateUrl: './vizsgafeladat.component.html',
  styleUrls: ['./vizsgafeladat.component.css']
})
export class VizsgafeladatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
